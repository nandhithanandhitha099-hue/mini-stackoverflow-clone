const cors = require("cors");
const express = require("express");

const app = express();

app.use(cors());
app.use(express.json());

// Store questions in array
let posts = [
  { id: 1, title: "First Post" }
];

// Home route
app.get("/", (req, res) => {
  res.send("Mini Stack Overflow Backend Running");
});

// Get all posts
app.get("/api/posts", (req, res) => {
  res.json(posts);
});

// Add question
app.post("/api/createuser", (req, res) => {
  const newPost = {
    id: posts.length + 1,
    title: req.body.title
  };

  posts.push(newPost);

  res.json({
    message: "Question added successfully"
  });
});

// Start server
app.delete("/api/posts/:id", async (req, res) => {

  await Post.findByIdAndDelete(req.params.id);

  res.json({
    message: "Question deleted"
  });

});
app.listen(5000, () => {
  console.log("Server started on port 5000");
});